/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginsystem;

import static java.lang.System.in;
import java.util.Scanner;


/**
 *
 * @author 90851285
 */
public class LoginsYstem {
    
     public String user_name;
    public int user_id = 1;
    private String password;
    public static int count = 1;
    public static String input;

    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Create an input Stream
       
        
        String Username;
        String Password;
        String input;
        int choice;
        
        Password = "2002";
        Username = "Bongani";
        
        Scanner input1 = new Scanner(System.in);
        System.out.println("Enter Username : ");
        String username = input1.next();
        
        Scanner input2 = new Scanner(System.in);
        System.out.println("Enter Username : ");
        String password = input1.next();
        
        if (username.equals(Username) && password.equals(Password)){
            
            System.out.println("Access Granted! Welcome!");
            
        }
        
        else if (username.equals(Username)){
            System.out.println("Invalid Username!");
        } else if (password.equals(Password)){
            System.out.println("Invalid Password");
        } else {
            System.out.println("Invalid Username & Password!");
        } 
        
       
       {
            System.out.println("Welcome to Easykanban");
            
            //Output menu:
            
            System.out.println("   Main menu      ");
            System.out.println("1. Add Tasks     1");
            System.out.println("2. show report   2");
            System.out.println("2. Coming soon   2");
            System.out.println("3. QUITE         3");
            
            //ASK USER FOR CHOICE
            System.out.println("what is your choice ?");
            //get input 
            input = in.readLine();
            
            choice = Integer.parseInt(input);
            
            
            }
            while (choice ! = 4);
            
        
    }

    public static void login(String Luser, String Lpassword) {
        for (int i = 1; i <= count; i++) {
            System.out.printf("Enter 'login' to log in or 'register' to open another account");
            
        }
        
         public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("login");
        System.out.println("register");
        input = scanner.nextLine();


            while (input.equals("login")) {

                System.out.println("username");
                String Luser = scanner.nextLine();
                System.out.println("Password");
                String Lpassword = scanner.nextLine();
                int a = count;
                login(Luser, Lpassword);
                System.out.println("");
                input = scanner.nextLine();
            }
                input = scanner.nextLine();
                
                
                 while (input.equals("register")) {

                System.out.println("username");
                String Ruser = scanner.nextLine();
                System.out.println("Password");
                String Rpassword = scanner.nextLine();
                users count = new users(Ruser, Rpassword);
                System.out.println("");
                input = scanner.nextLine();
                
                 while ((!input.equals("register")) || (!input.equals("login"))) {
                System.out.println("invild option, chose login or regiser!");
                input = scanner.nextLine();
        
        
       }

     
     }

   
    }
    
}
